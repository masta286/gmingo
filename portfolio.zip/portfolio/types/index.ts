export type NavItem = { label: string; href: string };

export type SocialLink = {
  label: string;
  /** Leave empty ("") until you have the real URL. Empty links render as "Coming soon" and are not clickable. */
  href: string;
  /** Text shown next to the label, e.g. your handle. */
  display: string;
};

export type Project = {
  slug: string;
  title: string;
  year: string;
  category: string;
  description: string;
  technologies: string[];
  role: string;
  /** Path inside /public, e.g. "/projects/my-app.png". Optional. */
  image?: string;
  imageAlt?: string;
  liveUrl?: string;
  githubUrl?: string;
};

export type Offering = {
  title: string;
  description: string;
  index: string;
};

export type CurrentlyItem = {
  label: string;
  description: string;
  /** Optional short items shown as tags under the description. */
  items?: string[];
};

export type JourneyEntry = {
  year: string;
  title: string;
  description: string;
};

export type SkillGroup = {
  title: string;
  description?: string;
  skills: string[];
};

export type Certification = {
  title: string;
  issuer?: string;
  year: string;
  /** Optional link to a credential or verification page. */
  url?: string;
};

export type Activity = {
  title: string;
  description?: string;
};

export type LoopStep = { word: string; caption: string };
