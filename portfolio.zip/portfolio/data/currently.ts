import type { CurrentlyItem } from "@/types";

/** Update these three as your focus changes. */
export const currently: CurrentlyItem[] = [
  {
    label: "Learning",
    description:
      "Software engineering, web development, and modern development tools.",
  },
  {
    label: "Building",
    description:
      "Personal projects, university projects, and eventually client projects.",
  },
  {
    label: "Exploring",
    description:
      "Digital products, entrepreneurship, AI, SaaS, and technology businesses.",
  },
];
