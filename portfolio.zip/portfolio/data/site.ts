import type { LoopStep, NavItem, SocialLink } from "@/types";

/**
 * ─── SITE CONTENT ──────────────────────────────────────────────
 * Edit this file to update your name, links and contact details.
 * Leave a link as "" until you have the real one — the site shows
 * a tasteful "Coming soon" state instead of a broken link.
 */

export const site = {
  name: "Abdallah Nura Kakira",
  shortName: "Abdallah",
  initials: "AK",
  role: "Software Developer · Computer Science Student · Product Builder",
  location: "Nigeria",
  title: "Abdallah Nura Kakira — Software Developer & Product Builder",
  description:
    "Computer Science student at Skyline University Nigeria, building toward software engineering and technology entrepreneurship. Web development, software, and digital products.",
  /** Set to your deployed URL when you have one, e.g. "https://abdallah.dev" */
  url: "https://example.com",
  hero: {
    lines: ["I BUILD", "DIGITAL", "PRODUCTS."],
    statement:
      "Computer Science student, software developer, and product builder exploring web development, software engineering, and technology entrepreneurship.",
    primaryCta: { label: "View My Work", href: "#work" },
    secondaryCta: { label: "About Me", href: "#about" },
  },
  navCta: { label: "Let’s Build", href: "#contact" },
  contact: {
    email: "kakiraabdallah709@gmail.com",
    /** Phone / WhatsApp number exactly as you want it displayed. */
    phone: "09166696965",
    /** Country calling code (Nigeria), used to build the tel: and WhatsApp links. */
    countryCode: "234",
    emailSubject: "Hello from your portfolio",
    heading: "Let’s Build Something.",
    text: "I’m interested in learning, collaborating, building useful technology, and connecting with people working on interesting ideas.",
  },
};

export const navItems: NavItem[] = [
  { label: "About", href: "#about" },
  { label: "Work", href: "#work" },
  { label: "Journey", href: "#journey" },
  { label: "Skills", href: "#skills" },
  { label: "Contact", href: "#contact" },
];

export const socials: SocialLink[] = [
  { label: "GitHub", href: "", display: "github.com/your-username" },
  { label: "LinkedIn", href: "", display: "linkedin.com/in/your-name" },
];

/**
 * Contact links derived from `site.contact`. The number is never retyped:
 * the leading local "0" is swapped for the country code (09166696965 → 2349166696965).
 */
const internationalNumber = `${site.contact.countryCode}${site.contact.phone
  .replace(/\D/g, "")
  .replace(/^0/, "")}`;

export const contactLinks = {
  email: `mailto:${site.contact.email}`,
  phone: `tel:+${internationalNumber}`,
  whatsapp: `https://wa.me/${internationalNumber}`,
};

/** The recurring motif. */
export const loop: LoopStep[] = [
  { word: "Learn", caption: "Fundamentals first" },
  { word: "Build", caption: "Make real things" },
  { word: "Solve", caption: "Real problems" },
  { word: "Create", caption: "Original products" },
  { word: "Grow", caption: "Compound over time" },
];
