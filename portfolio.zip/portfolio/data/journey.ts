import type { JourneyEntry } from "@/types";

/**
 * Add a new year by appending an entry. Only write what has actually happened.
 */
export const journey: JourneyEntry[] = [
  {
    year: "2024",
    title: "The foundation",
    description:
      "Started my university journey and began developing my Computer Science foundation.",
  },
  {
    year: "2025",
    title: "Skills & certifications",
    description:
      "Developed technical skills, completed certifications, participated in technology activities, and worked on university projects.",
  },
  {
    year: "2026",
    title: "Building real experience",
    description:
      "Focus on software development, web development, personal projects, and building real-world experience.",
  },
];

/** Shown as the final, faded node on the timeline. Update when ready. */
export const whatsNext = {
  label: "What’s next",
  text: "The next chapter is still being written. Updates will land here as it happens.",
};
