import type { Offering } from "@/types";

export const offerings: Offering[] = [
  {
    index: "01",
    title: "Web Development",
    description: "Building websites and web-based experiences.",
  },
  {
    index: "02",
    title: "Software",
    description:
      "Developing practical software solutions while strengthening my engineering skills.",
  },
  {
    index: "03",
    title: "Digital Products",
    description: "Turning ideas and problems into useful technology products.",
  },
  {
    index: "04",
    title: "Entrepreneurship",
    description:
      "Exploring how technology can become sustainable products and businesses.",
  },
];
