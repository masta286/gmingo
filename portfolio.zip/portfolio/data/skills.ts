import type { SkillGroup } from "@/types";

export const skillGroups: SkillGroup[] = [
  { title: "Programming", skills: ["Java", "C", "Python"] },
  { title: "Web Development", skills: ["HTML", "CSS", "WordPress"] },
  { title: "Data", skills: ["Excel", "SPSS", "STATA"] },
  {
    title: "Computer Science",
    skills: ["Algorithms", "Data Structures", "Computational Theory"],
  },
  {
    title: "Professional",
    skills: [
      "Problem Solving",
      "Critical Thinking",
      "Teamwork",
      "Interpersonal Skills",
      "Time Management",
      "Adaptability",
    ],
  },
];

export const education = {
  degree: "B.Sc. Computer Science",
  school: "Skyline University Nigeria",
  status: "In Progress",
};
