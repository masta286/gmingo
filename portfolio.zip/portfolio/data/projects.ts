import type { Project } from "@/types";

/**
 * ─── PROJECTS ──────────────────────────────────────────────────
 * This array is intentionally empty. While it is empty, the site shows
 * an elegant "More projects coming soon" state.
 *
 * To add a project, copy the template below into the array and fill it in.
 * Only title, year, category, description, technologies and role are required.
 * Links and image are optional — buttons simply don't render when omitted.
 *
 *   {
 *     slug: "my-first-project",
 *     title: "Project name",
 *     year: "2026",
 *     category: "Web Development",
 *     description: "One or two sentences about what it does and why.",
 *     technologies: ["HTML", "CSS"],          // only what you really used
 *     role: "Designer & Developer",
 *     image: "/projects/my-first-project.png", // put the file in /public/projects
 *     imageAlt: "Screenshot of the home page",
 *     liveUrl: "https://…",
 *     githubUrl: "https://github.com/…",
 *   },
 */
export const projects: Project[] = [];

export const projectsEmpty = {
  title: "More projects coming soon",
  text: "I’m currently learning, building and refining. Real projects will appear here as I ship them — each one with its story, stack and links.",
};
