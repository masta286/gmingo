import type { Activity, Certification } from "@/types";

/** Add new certifications to the top of this list. */
export const certifications: Certification[] = [
  {
    title: "Tech Powered Games Certificate",
    issuer: "Skyline University Nigeria",
    year: "2025",
  },
  {
    title: "Python for Data Science & Development Certificate",
    year: "2025",
  },
  {
    title: "Introduction to IT Certificate",
    year: "2025",
  },
];

export const activities: Activity[] = [
  { title: "University software projects" },
  { title: "Coding workshops" },
  { title: "Technology talks" },
  { title: "Hackathons" },
  { title: "Collaborative projects" },
  { title: "University football team" },
];

export const about = {
  title: "Who I Am",
  paragraphs: [
    "I’m a Computer Science student at Skyline University Nigeria, with a growing focus on software development and building practical technology solutions.",
    "My academic journey has given me a foundation in algorithmic thinking, data structures, computational theory, and programming. Alongside my coursework, I have worked on software projects, participated in coding workshops, technology talks, collaborative projects, and hackathons.",
    "I’m particularly interested in web development and software engineering. I enjoy learning how technology works, solving problems, and turning ideas into useful digital solutions.",
    "My long-term goal is to become a strong software and computer engineer, build products that solve real problems, and eventually start my own technology company.",
  ],
  /** Put your photo at /public/profile.jpg then set this to "/profile.jpg". */
  photo: "" as string,
};
