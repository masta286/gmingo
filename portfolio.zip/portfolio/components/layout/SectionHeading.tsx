import type { ReactNode } from "react";
import { LoopIndicator } from "@/components/ui/LoopIndicator";
import { Reveal } from "@/components/ui/Reveal";

type SectionHeadingProps = {
  id: string;
  index: string;
  label: string;
  title: string;
  /** Position in LEARN → BUILD → SOLVE → CREATE → GROW (0–4). Optional. */
  step?: number;
  children?: ReactNode;
};

export function SectionHeading({
  id,
  index,
  label,
  title,
  step,
  children,
}: SectionHeadingProps) {
  return (
    <header className="mb-12 md:mb-16">
      <div className="flex items-center justify-between gap-4 border-b border-line pb-4">
        <span className="eyebrow">
          {index} — {label}
        </span>
        {step !== undefined && <LoopIndicator step={step} />}
      </div>
      <Reveal>
        <h2
          id={id}
          className="display mt-8 max-w-4xl text-[clamp(2.4rem,7vw,5.25rem)] md:mt-10"
        >
          {title}
        </h2>
        {children && (
          <div className="mt-6 max-w-2xl text-lg leading-relaxed text-muted">
            {children}
          </div>
        )}
      </Reveal>
    </header>
  );
}
