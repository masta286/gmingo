import { socialIcons } from "@/components/ui/Icons";
import { loop, site, socials } from "@/data/site";

const mailHref = site.contact.email ? `mailto:${site.contact.email}` : "";

const links = [
  { label: "GitHub" as const, href: socials.find((s) => s.label === "GitHub")?.href ?? "" },
  { label: "LinkedIn" as const, href: socials.find((s) => s.label === "LinkedIn")?.href ?? "" },
  { label: "Email" as const, href: mailHref },
];

export function Footer() {
  return (
    <footer className="border-t border-line">
      <div className="container-x py-14 md:py-20">
        <div className="flex flex-col gap-10 md:flex-row md:items-end md:justify-between">
          <div>
            <p className="display text-2xl md:text-3xl">{site.name.toUpperCase()}</p>
            <p className="mt-3 text-muted">{site.role}</p>
            <p className="eyebrow mt-2">{site.location}</p>
          </div>

          <ul className="flex items-center gap-3">
            {links.map(({ label, href }) => {
              const Icon = socialIcons[label];
              const base =
                "flex size-11 items-center justify-center rounded-full border border-line transition-colors duration-300";
              return (
                <li key={label}>
                  {href ? (
                    <a
                      href={href}
                      target={label === "Email" ? undefined : "_blank"}
                      rel={label === "Email" ? undefined : "noopener noreferrer"}
                      aria-label={label}
                      className={`${base} text-ink hover:border-accent/60 hover:text-accent`}
                    >
                      <Icon />
                    </a>
                  ) : (
                    <span
                      aria-label={`${label} — coming soon`}
                      title={`${label} — coming soon`}
                      className={`${base} cursor-default text-muted/60`}
                    >
                      <Icon />
                    </span>
                  )}
                </li>
              );
            })}
          </ul>
        </div>

        <div className="mt-14 flex flex-col gap-4 border-t border-line pt-6 md:flex-row md:items-center md:justify-between">
          <p className="eyebrow">
            © {new Date().getFullYear()} {site.name}
          </p>
          <p aria-hidden className="eyebrow !text-muted/70">
            {loop.map((s) => s.word).join(" → ")}
          </p>
        </div>
      </div>
    </footer>
  );
}
