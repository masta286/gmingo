"use client";

import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import { useEffect, useState } from "react";
import { ArrowRight } from "@/components/ui/Icons";
import { navItems, site } from "@/data/site";
import { cn } from "@/lib/utils";

export function Navbar() {
  const reduce = useReducedMotion();
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState<string>("");

  // Compact on scroll
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 80);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  // Active section indicator
  useEffect(() => {
    const ids = navItems.map((n) => n.href.slice(1));
    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting) setActive(entry.target.id);
        }
      },
      { rootMargin: "-40% 0px -55% 0px" },
    );
    ids.forEach((id) => {
      const el = document.getElementById(id);
      if (el) observer.observe(el);
    });
    return () => observer.disconnect();
  }, []);

  // Mobile menu: lock scroll, close on Escape
  useEffect(() => {
    if (!open) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = prev;
      window.removeEventListener("keydown", onKey);
    };
  }, [open]);

  const close = () => setOpen(false);

  return (
    <>
      <header className="container-x fixed inset-x-0 top-0 z-50 pt-3">
        <nav
          aria-label="Primary"
          className={cn(
            "mx-auto flex w-full items-center justify-between rounded-full border transition-[max-width,height,padding,background-color,border-color] duration-500 ease-out",
            scrolled && !open
              ? "h-12 max-w-3xl border-line bg-[rgb(10_12_16/0.7)] px-4 backdrop-blur-xl sm:px-5"
              : "h-16 max-w-full border-transparent bg-transparent px-0",
          )}
        >
          <a
            href="#top"
            onClick={close}
            className="font-semibold tracking-[0.08em] text-ink"
            aria-label={`${site.name} — back to top`}
          >
            ABDALLAH<span className="text-accent">.</span>
          </a>

          <ul className="hidden items-center gap-1 md:flex">
            {navItems.map((item) => {
              const isActive = active === item.href.slice(1);
              return (
                <li key={item.href}>
                  <a
                    href={item.href}
                    aria-current={isActive ? "true" : undefined}
                    className={cn(
                      "rounded-full px-3.5 py-2 text-sm transition-colors duration-300",
                      isActive
                        ? "bg-white/[0.07] text-ink"
                        : "text-muted hover:text-ink",
                    )}
                  >
                    {item.label}
                  </a>
                </li>
              );
            })}
          </ul>

          <div className="flex items-center gap-2">
            <a
              href={site.navCta.href}
              className="group hidden h-9 items-center gap-1.5 rounded-full border border-line-strong px-4 text-sm text-ink transition-colors duration-300 hover:border-accent/60 hover:text-accent md:inline-flex"
            >
              {site.navCta.label}
              <ArrowRight
                width={15}
                height={15}
                className="transition-transform duration-300 group-hover:translate-x-0.5"
              />
            </a>

            <button
              type="button"
              onClick={() => setOpen((v) => !v)}
              aria-expanded={open}
              aria-controls="mobile-menu"
              aria-label={open ? "Close menu" : "Open menu"}
              className="relative -mr-2 flex size-11 items-center justify-center md:hidden"
            >
              <span
                className={cn(
                  "absolute h-px w-5 bg-ink transition-transform duration-300",
                  open ? "rotate-45" : "-translate-y-[3px]",
                )}
              />
              <span
                className={cn(
                  "absolute h-px w-5 bg-ink transition-transform duration-300",
                  open ? "-rotate-45" : "translate-y-[3px]",
                )}
              />
            </button>
          </div>
        </nav>
      </header>

      <AnimatePresence>
        {open && (
          <motion.div
            id="mobile-menu"
            role="dialog"
            aria-modal="true"
            aria-label="Menu"
            initial={reduce ? false : { opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={reduce ? undefined : { opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="fixed inset-0 z-40 flex h-dvh flex-col bg-bg/95 px-6 pb-8 pt-24 backdrop-blur-2xl md:hidden"
          >
            <ul className="flex flex-1 flex-col justify-center gap-1">
              {navItems.map((item, i) => (
                <motion.li
                  key={item.href}
                  initial={reduce ? false : { opacity: 0, y: 14 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.08 + i * 0.05, duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
                >
                  <a
                    href={item.href}
                    onClick={close}
                    className="display flex items-baseline gap-4 py-2.5 text-[2.6rem] text-ink"
                  >
                    <span className="font-mono text-xs font-normal tracking-widest text-muted">
                      0{i + 1}
                    </span>
                    {item.label}
                  </a>
                </motion.li>
              ))}
            </ul>

            <a
              href={site.navCta.href}
              onClick={close}
              className="flex h-14 items-center justify-center gap-2 rounded-full bg-ink text-base font-medium text-bg"
            >
              {site.navCta.label}
              <ArrowRight />
            </a>
            <p className="eyebrow mt-6 text-center">
              Learn → Build → Solve → Create → Grow
            </p>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
