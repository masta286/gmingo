import { SectionHeading } from "@/components/layout/SectionHeading";
import { Button } from "@/components/ui/Button";
import { ArrowRight } from "@/components/ui/Icons";
import { Reveal } from "@/components/ui/Reveal";
import { projects, projectsEmpty } from "@/data/projects";
import { ProjectCard } from "./ProjectCard";

function ComingSoon() {
  return (
    <Reveal>
      <div className="relative overflow-hidden rounded-3xl border border-dashed border-line-strong bg-surface/40 p-6 sm:p-8 md:p-14">
        <div
          aria-hidden
          className="pointer-events-none absolute inset-0"
          style={{
            background:
              "radial-gradient(ellipse at 50% 0%, rgb(56 189 248 / 0.08), transparent 60%)",
          }}
        />

        {/* Ghost frames: the shape of what will live here */}
        <div aria-hidden className="relative grid gap-3 sm:grid-cols-3 sm:gap-4">
          {["01", "02", "03"].map((n, i) => (
            <div
              key={n}
              className={`relative aspect-[16/10] rounded-2xl border bg-bg/50 p-4 ${i === 0 ? "border-accent/30" : "border-line"} ${i > 0 ? "hidden sm:block" : ""}`}
            >
              <span className="eyebrow">{n}</span>
              <div className="absolute inset-x-4 bottom-4 space-y-2">
                <div className="h-2 w-2/3 rounded-full bg-white/[0.08]" />
                <div className="h-1.5 w-1/2 rounded-full bg-white/[0.05]" />
              </div>
            </div>
          ))}
        </div>

        <div className="relative mt-10 max-w-2xl md:mt-14">
          <h3 className="display text-[clamp(1.9rem,4.5vw,3.25rem)] leading-[1.02]">
            {projectsEmpty.title}
          </h3>
          <p className="mt-5 text-lg leading-relaxed text-muted">
            {projectsEmpty.text}
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Button href="#journey" variant="secondary">
              Follow the journey
            </Button>
            <Button href="#contact" variant="ghost" className="px-3">
              Say hello
              <ArrowRight className="transition-transform duration-300 group-hover:translate-x-0.5" />
            </Button>
          </div>
        </div>
      </div>
    </Reveal>
  );
}

export function Projects() {
  return (
    <section id="work" aria-labelledby="work-title" className="section-y">
      <div className="container-x">
        <SectionHeading
          id="work-title"
          index="03"
          label="Work"
          title="Selected Work"
          step={2}
        >
          A growing collection of work, each project with its story, stack and links.
        </SectionHeading>

        {projects.length === 0 ? (
          <ComingSoon />
        ) : (
          <div className="space-y-20 md:space-y-28">
            {projects.map((project, i) => (
              <Reveal key={project.slug}>
                <ProjectCard project={project} flip={i % 2 === 1} />
              </Reveal>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
