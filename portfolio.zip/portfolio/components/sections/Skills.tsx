import { SectionHeading } from "@/components/layout/SectionHeading";
import { Reveal } from "@/components/ui/Reveal";
import { SpotlightCard } from "@/components/ui/SpotlightCard";
import { Tag } from "@/components/ui/Tag";
import { skillGroups } from "@/data/skills";
import { cn } from "@/lib/utils";

/** Column spans at lg (6-col grid). Falls back to 2 when more groups are added. */
const lgSpan = ["lg:col-span-2", "lg:col-span-2", "lg:col-span-2", "lg:col-span-2", "lg:col-span-4"];

export function Skills() {
  return (
    <section id="skills" aria-labelledby="skills-title" className="section-y">
      <div className="container-x">
        <SectionHeading
          id="skills-title"
          index="06"
          label="Skills"
          title="Skills"
        >
          What I work with today, and what I keep sharpening.
        </SectionHeading>

        <ul className="grid gap-4 md:grid-cols-2 lg:grid-cols-6">
          {skillGroups.map((group, i) => (
            <li
              key={group.title}
              className={cn(lgSpan[i] ?? "lg:col-span-2", i === skillGroups.length - 1 && skillGroups.length % 2 === 1 && "md:col-span-2")}
            >
              <Reveal delay={(i % 3) * 0.07} className="h-full">
                <SpotlightCard className="p-7 md:p-8">
                  <div className="flex items-baseline justify-between">
                    <h3 className="text-xl font-semibold tracking-tight">
                      {group.title}
                    </h3>
                    <span aria-hidden className="eyebrow">
                      {String(group.skills.length).padStart(2, "0")}
                    </span>
                  </div>
                  <ul className="mt-6 flex flex-wrap gap-2.5">
                    {group.skills.map((skill) => (
                      <li key={skill}>
                        <Tag>{skill}</Tag>
                      </li>
                    ))}
                  </ul>
                </SpotlightCard>
              </Reveal>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
