import { SectionHeading } from "@/components/layout/SectionHeading";
import { ArrowUpRight } from "@/components/ui/Icons";
import { Reveal } from "@/components/ui/Reveal";
import { activities, certifications } from "@/data/credentials";

export function Credentials() {
  return (
    <section
      id="credentials"
      aria-labelledby="credentials-title"
      className="section-y"
    >
      <div className="container-x">
        <SectionHeading
          id="credentials-title"
          index="07"
          label="Credentials"
          title="Certifications & Activities"
        />

        <div className="grid gap-14 lg:grid-cols-12 lg:gap-16">
          <div className="lg:col-span-7">
            <h3 className="eyebrow mb-5">Certifications</h3>
            <ul className="border-t border-line">
              {certifications.map((cert, i) => (
                <li key={cert.title} className="border-b border-line">
                  <Reveal delay={i * 0.06}>
                    <div className="flex items-start justify-between gap-6 py-6">
                      <div>
                        <p className="text-lg font-medium tracking-tight md:text-xl">
                          {cert.url ? (
                            <a
                              href={cert.url}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="inline-flex items-center gap-2 hover:text-accent"
                            >
                              {cert.title}
                              <ArrowUpRight width={16} height={16} />
                              <span className="sr-only">(opens in a new tab)</span>
                            </a>
                          ) : (
                            cert.title
                          )}
                        </p>
                        {cert.issuer && (
                          <p className="mt-1.5 text-muted">{cert.issuer}</p>
                        )}
                      </div>
                      <span className="eyebrow pt-1.5">{cert.year}</span>
                    </div>
                  </Reveal>
                </li>
              ))}
            </ul>
            <p className="mt-5 text-sm text-muted">More to come as I keep learning.</p>
          </div>

          <div className="lg:col-span-5">
            <h3 className="eyebrow mb-5">Activities</h3>
            <Reveal>
              <ul className="flex flex-wrap gap-2.5">
                {activities.map((a) => (
                  <li
                    key={a.title}
                    className="rounded-full border border-line bg-white/[0.03] px-4 py-2.5 text-[0.95rem] text-ink/90 transition-colors duration-300 hover:border-accent/40"
                  >
                    {a.title}
                  </li>
                ))}
              </ul>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}
