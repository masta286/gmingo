import { Reveal } from "@/components/ui/Reveal";
import { education } from "@/data/skills";

export function Education() {
  return (
    <section
      id="education"
      aria-labelledby="education-title"
      className="pb-16 md:pb-24"
    >
      <div className="container-x">
        <Reveal>
          <div className="flex flex-col gap-6 border-y border-line py-8 md:flex-row md:items-center md:justify-between md:py-10">
            <div>
              <h2 id="education-title" className="eyebrow">
                Education
              </h2>
              <p className="mt-3 text-2xl font-semibold tracking-tight md:text-3xl">
                {education.degree}
              </p>
              <p className="mt-1 text-muted">{education.school}</p>
            </div>
            <span className="inline-flex w-fit items-center gap-2.5 rounded-full border border-accent/30 bg-accent/[0.06] px-4 py-2 font-mono text-xs uppercase tracking-[0.14em] text-accent">
              <span className="size-1.5 rounded-full bg-accent" />
              {education.status}
            </span>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
