import { SectionHeading } from "@/components/layout/SectionHeading";
import { Reveal } from "@/components/ui/Reveal";
import { journey, whatsNext } from "@/data/journey";

export function Journey() {
  return (
    <section id="journey" aria-labelledby="journey-title" className="section-y">
      <div className="container-x">
        <SectionHeading
          id="journey-title"
          index="05"
          label="Journey"
          title="My Journey"
          step={4}
        />

        <ol className="relative">
          {/* Spine */}
          <span
            aria-hidden
            className="absolute bottom-0 left-[5px] top-2 w-px bg-gradient-to-b from-accent/70 via-line-strong to-transparent md:left-[10rem]"
          />

          {journey.map((entry, i) => (
            <li
              key={entry.year}
              className="relative pb-14 pl-9 md:grid md:grid-cols-[10rem_1fr] md:pb-20 md:pl-0"
            >
              <span
                aria-hidden
                className="absolute left-0 top-3 size-[11px] rounded-full border border-accent bg-bg shadow-[0_0_14px_rgb(56_189_248/0.5)] md:left-[10rem] md:top-5 md:-translate-x-1/2"
              />
              <Reveal delay={i * 0.04} className="md:pr-10 md:text-right">
                <h3 className="display text-5xl text-ink md:text-6xl">
                  {entry.year}
                </h3>
              </Reveal>
              <Reveal delay={0.08 + i * 0.04} className="mt-3 md:mt-0 md:pl-10">
                <p className="text-xl font-medium tracking-tight">{entry.title}</p>
                <p className="mt-2 max-w-xl text-lg leading-relaxed text-muted">
                  {entry.description}
                </p>
              </Reveal>
            </li>
          ))}

          {/* What's next — deliberately quiet */}
          <li className="relative pl-9 md:grid md:grid-cols-[10rem_1fr] md:pl-0">
            <span
              aria-hidden
              className="absolute left-0 top-3 size-[11px] rounded-full border border-dashed border-muted bg-bg md:left-[10rem] md:top-4 md:-translate-x-1/2"
            />
            <Reveal className="md:pr-10 md:text-right">
              <p className="eyebrow pt-1.5 md:pt-2.5">{whatsNext.label}</p>
            </Reveal>
            <Reveal delay={0.08} className="mt-3 md:mt-0 md:pl-10">
              <div className="max-w-xl rounded-2xl border border-dashed border-line-strong p-5 text-muted">
                {whatsNext.text}
              </div>
            </Reveal>
          </li>
        </ol>
      </div>
    </section>
  );
}
