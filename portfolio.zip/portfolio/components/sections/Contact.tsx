import { ArrowUpRight, socialIcons } from "@/components/ui/Icons";
import { Reveal } from "@/components/ui/Reveal";
import { contactLinks, site } from "@/data/site";
import { ContactForm } from "./ContactForm";

type Row = {
  label: "Email" | "Phone" | "WhatsApp";
  display: string;
  href: string;
  /** Opens in a new tab (web links only; mailto: and tel: hand off to the device). */
  external?: boolean;
};

const rows: Row[] = [
  { label: "Email", display: site.contact.email, href: contactLinks.email },
  { label: "Phone", display: site.contact.phone, href: contactLinks.phone },
  {
    label: "WhatsApp",
    display: site.contact.phone,
    href: contactLinks.whatsapp,
    external: true,
  },
];

export function Contact() {
  return (
    <section
      id="contact"
      aria-labelledby="contact-title"
      className="section-y relative overflow-hidden"
    >
      <div
        aria-hidden
        className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-accent/40 to-transparent"
      />
      <div className="container-x">
        <p className="eyebrow border-b border-line pb-4">08 — Contact</p>

        <div className="mt-10 grid gap-14 lg:mt-14 lg:grid-cols-12 lg:gap-16">
          <div className="lg:col-span-6">
            <Reveal>
              <h2
                id="contact-title"
                className="display text-[clamp(2.75rem,8.5vw,6.5rem)]"
              >
                Let’s Build{" "}
                <span className="text-gradient">Something.</span>
              </h2>
              <p className="mt-7 max-w-lg text-lg leading-relaxed text-muted md:text-xl">
                {site.contact.text}
              </p>
            </Reveal>

            <Reveal delay={0.1}>
              <ul className="mt-10 border-t border-line">
                {rows.map((row) => {
                  const Icon = socialIcons[row.label];
                  return (
                    <li key={row.label} className="border-b border-line">
                      <a
                        href={row.href}
                        target={row.external ? "_blank" : undefined}
                        rel={row.external ? "noopener noreferrer" : undefined}
                        className="group flex min-h-[4.5rem] items-center justify-between gap-4 py-5"
                      >
                        <span className="flex min-w-0 items-center gap-4">
                          <span className="flex size-11 shrink-0 items-center justify-center rounded-full border border-line bg-white/[0.03] transition-colors duration-300 group-hover:border-accent/50">
                            <Icon className="text-accent" />
                          </span>
                          <span className="min-w-0">
                            <span className="eyebrow block">{row.label}</span>
                            <span className="mt-1 block text-lg font-medium tracking-tight text-ink [overflow-wrap:anywhere] sm:text-xl md:text-2xl">
                              {row.display}
                            </span>
                          </span>
                        </span>
                        <ArrowUpRight className="shrink-0 text-muted transition-all duration-300 group-hover:-translate-y-0.5 group-hover:translate-x-0.5 group-hover:text-accent" />
                        {row.external && (
                          <span className="sr-only">(opens in a new tab)</span>
                        )}
                      </a>
                    </li>
                  );
                })}
              </ul>
            </Reveal>
          </div>

          <Reveal delay={0.15} className="lg:col-span-6">
            <div className="glass rounded-3xl p-6 sm:p-8 md:p-10">
              <ContactForm />
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
