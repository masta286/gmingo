"use client";

import { useState, type FormEvent } from "react";
import { ArrowRight } from "@/components/ui/Icons";
import { site } from "@/data/site";

const field =
  "w-full rounded-xl border border-line bg-bg/60 px-4 py-3.5 text-base text-ink placeholder:text-muted/60 transition-colors duration-300 hover:border-line-strong focus:border-accent/70 focus:outline-none focus:ring-2 focus:ring-accent/25";

/**
 * v1: no backend. Submitting opens the visitor's email app with the message pre-filled.
 * To upgrade later, swap `onSubmit` for a call to an API route.
 */
export function ContactForm() {
  const [sent, setSent] = useState(false);

  const onSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const data = new FormData(e.currentTarget);
    const name = String(data.get("name") ?? "").trim();
    const email = String(data.get("email") ?? "").trim();
    const message = String(data.get("message") ?? "").trim();

    const body = `${message}\n\n— ${name}${email ? `\n${email}` : ""}`;
    const href = `mailto:${site.contact.email}?subject=${encodeURIComponent(
      `${site.contact.emailSubject} — ${name}`,
    )}&body=${encodeURIComponent(body)}`;

    window.location.href = href;
    setSent(true);
  };

  return (
    <form onSubmit={onSubmit} className="space-y-5">
      <div>
        <label htmlFor="name" className="eyebrow mb-2 block">
          Name
        </label>
        <input
          id="name"
          name="name"
          type="text"
          required
          autoComplete="name"
          placeholder="Your name"
          className={field}
        />
      </div>
      <div>
        <label htmlFor="email" className="eyebrow mb-2 block">
          Email
        </label>
        <input
          id="email"
          name="email"
          type="email"
          required
          autoComplete="email"
          placeholder="you@example.com"
          className={field}
        />
      </div>
      <div>
        <label htmlFor="message" className="eyebrow mb-2 block">
          Message
        </label>
        <textarea
          id="message"
          name="message"
          required
          rows={5}
          placeholder="What would you like to build or talk about?"
          className={`${field} resize-y`}
        />
      </div>

      <button
        type="submit"
        className="group inline-flex h-12 w-full items-center justify-center gap-2 rounded-full bg-ink px-6 text-[0.95rem] font-medium text-bg transition-all duration-300 hover:bg-white hover:shadow-[0_0_0_6px_rgb(56_189_248/0.14)] sm:w-auto"
      >
        Send message
        <ArrowRight className="transition-transform duration-300 group-hover:translate-x-0.5" />
      </button>

      <p role="status" aria-live="polite" className="min-h-5 text-sm text-muted">
        {sent
          ? "Opening your email app with the message ready to send."
          : "This opens your email app with the message pre-filled."}
      </p>
    </form>
  );
}
