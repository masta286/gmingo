import Image from "next/image";
import { ArrowUpRight, GithubIcon } from "@/components/ui/Icons";
import { Tag } from "@/components/ui/Tag";
import type { Project } from "@/types";
import { cn } from "@/lib/utils";

/**
 * Large visual showcase. Pure CSS hover (no client JS). On touch devices the
 * links are always visible; with a real pointer they slide in on hover or focus.
 */
export function ProjectCard({ project, flip }: { project: Project; flip?: boolean }) {
  const { title, year, category, description, technologies, role, image, imageAlt, liveUrl, githubUrl } = project;

  return (
    <article className="group grid items-center gap-7 lg:grid-cols-12 lg:gap-14">
      {/* Preview */}
      <div className={cn("lg:col-span-7", flip && "lg:order-2")}>
        <div className="relative aspect-[16/10] overflow-hidden rounded-3xl border border-line bg-surface transition-colors duration-500 group-hover:border-line-strong">
          {image ? (
            <Image
              src={image}
              alt={imageAlt ?? `${title} preview`}
              fill
              sizes="(min-width: 1024px) 58vw, 100vw"
              className="object-cover transition-transform duration-700 ease-out group-hover:scale-[1.04]"
            />
          ) : (
            <div
              aria-hidden
              className="absolute inset-0 transition-transform duration-700 ease-out group-hover:scale-[1.04]"
              style={{
                background:
                  "radial-gradient(circle at 25% 20%, rgb(56 189 248 / 0.18), transparent 55%), radial-gradient(circle at 80% 85%, rgb(109 94 245 / 0.20), transparent 55%)",
              }}
            >
              <div className="bg-grid absolute inset-0" />
              <span className="display absolute bottom-6 left-7 text-5xl text-ink/80 md:text-7xl">
                {title}
              </span>
            </div>
          )}
          <div
            aria-hidden
            className="pointer-events-none absolute inset-0 bg-gradient-to-t from-bg/50 via-transparent to-transparent opacity-70 transition-opacity duration-500 group-hover:opacity-30"
          />
        </div>
      </div>

      {/* Details */}
      <div className={cn("lg:col-span-5", flip && "lg:order-1")}>
        <p className="eyebrow">
          {year} · {category}
        </p>
        <h3 className="display mt-4 text-[clamp(2rem,4.5vw,3.5rem)] leading-none transition-transform duration-500 ease-out group-hover:translate-x-1.5 lg:group-hover:translate-x-2.5">
          {title}
        </h3>
        <p className="mt-5 text-lg leading-relaxed text-muted">{description}</p>

        <dl className="mt-6 space-y-4">
          <div>
            <dt className="eyebrow">Role</dt>
            <dd className="mt-1.5 text-ink/90">{role}</dd>
          </div>
          <div>
            <dt className="eyebrow">Built with</dt>
            <dd className="mt-2.5 flex flex-wrap gap-2">
              {technologies.map((t) => (
                <Tag key={t}>{t}</Tag>
              ))}
            </dd>
          </div>
        </dl>

        {(liveUrl || githubUrl) && (
          <div className="mt-8 flex flex-wrap gap-3 transition-all duration-500 hoverable:translate-y-2 hoverable:opacity-0 hoverable:group-focus-within:translate-y-0 hoverable:group-focus-within:opacity-100 hoverable:group-hover:translate-y-0 hoverable:group-hover:opacity-100">
            {liveUrl && (
              <a
                href={liveUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="group/cta inline-flex h-11 items-center gap-2 rounded-full bg-ink px-5 text-sm font-medium text-bg transition-shadow hover:shadow-[0_0_0_6px_rgb(56_189_248/0.14)]"
              >
                View project
                <ArrowUpRight width={16} height={16} />
                <span className="sr-only">(opens in a new tab)</span>
              </a>
            )}
            {githubUrl && (
              <a
                href={githubUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex h-11 items-center gap-2 rounded-full border border-line-strong px-5 text-sm text-ink transition-colors hover:border-accent/60"
              >
                <GithubIcon width={16} height={16} />
                GitHub
                <span className="sr-only">(opens in a new tab)</span>
              </a>
            )}
          </div>
        )}
      </div>
    </article>
  );
}
