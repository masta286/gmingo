import { SectionHeading } from "@/components/layout/SectionHeading";
import { Reveal } from "@/components/ui/Reveal";
import { SpotlightCard } from "@/components/ui/SpotlightCard";
import { offeringGlyphs } from "@/components/visuals/Glyphs";
import { offerings } from "@/data/offerings";

export function WhatIBuild() {
  return (
    <section id="build" aria-labelledby="build-title" className="section-y">
      <div className="container-x">
        <SectionHeading
          id="build-title"
          index="02"
          label="Focus"
          title="What I Build"
          step={1}
        />

        <ul className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {offerings.map((item, i) => {
            const Glyph = offeringGlyphs[i % offeringGlyphs.length];
            return (
              <li key={item.title}>
                <Reveal delay={i * 0.08} className="h-full">
                  <SpotlightCard className="flex min-h-[18rem] flex-col justify-between p-7 md:min-h-[21rem] md:p-8">
                    <div className="flex items-start justify-between">
                      <span className="eyebrow">{item.index}</span>
                      <Glyph className="text-accent transition-transform duration-500 group-hover:-translate-y-1.5 group-hover:scale-105" />
                    </div>
                    <div>
                      <h3 className="text-2xl font-semibold tracking-tight">
                        {item.title}
                      </h3>
                      <p className="mt-3 leading-relaxed text-muted">
                        {item.description}
                      </p>
                    </div>
                  </SpotlightCard>
                </Reveal>
              </li>
            );
          })}
        </ul>
      </div>
    </section>
  );
}
