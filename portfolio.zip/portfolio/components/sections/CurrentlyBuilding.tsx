import { SectionHeading } from "@/components/layout/SectionHeading";
import { Reveal } from "@/components/ui/Reveal";
import { Tag } from "@/components/ui/Tag";
import { currently } from "@/data/currently";

export function CurrentlyBuilding() {
  return (
    <section
      id="currently"
      aria-labelledby="currently-title"
      className="section-y"
    >
      <div className="container-x">
        <SectionHeading
          id="currently-title"
          index="04"
          label="Now"
          title="Currently Building"
          step={3}
        />

        <ul className="border-t border-line">
          {currently.map((item, i) => (
            <li key={item.label} className="border-b border-line">
              <Reveal delay={i * 0.06}>
                <div className="group grid gap-4 py-9 md:grid-cols-12 md:gap-8 md:py-14">
                  <div className="md:col-span-6">
                    <p className="eyebrow flex items-center gap-2.5">
                      <span className="size-1.5 rounded-full bg-accent" />
                      0{i + 1}
                    </p>
                    <h3 className="display mt-4 text-[clamp(2.4rem,7vw,5rem)] transition-colors duration-500 group-hover:text-accent">
                      {item.label}
                    </h3>
                  </div>
                  <div className="md:col-span-5 md:col-start-8 md:self-end">
                    <p className="text-lg leading-relaxed text-muted md:text-xl">
                      {item.description}
                    </p>
                    {item.items && (
                      <div className="mt-5 flex flex-wrap gap-2">
                        {item.items.map((t) => (
                          <Tag key={t}>{t}</Tag>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </Reveal>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
