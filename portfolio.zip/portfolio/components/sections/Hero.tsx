import { Button } from "@/components/ui/Button";
import { ArrowDown, ArrowRight } from "@/components/ui/Icons";
import { HeroWorkspace } from "@/components/visuals/HeroWorkspace";
import { site } from "@/data/site";

export function Hero() {
  const { hero } = site;

  return (
    <section
      id="top"
      className="relative flex min-h-dvh flex-col justify-center overflow-hidden pb-24 pt-28 md:pb-28 md:pt-32"
    >
      <div aria-hidden className="bg-grid absolute inset-0" />

      <div className="container-x relative">
        <p
          className="anim-fade-up eyebrow flex items-center gap-3 !text-ink/80"
          style={{ animationDelay: "0.1s" }}
        >
          <span className="relative flex size-2">
            <span className="absolute inline-flex size-full animate-ping rounded-full bg-accent/60" />
            <span className="relative inline-flex size-2 rounded-full bg-accent" />
          </span>
          {site.name}
        </p>

        <h1 className="display mt-7 text-[clamp(3rem,15vw,7rem)] lg:mt-9 lg:text-[clamp(5rem,12vw,11rem)]">
          {hero.lines.map((line, i) => (
            <span key={line} className="block overflow-hidden pb-[0.06em]">
              <span
                className={`anim-rise block ${i === hero.lines.length - 1 ? "text-gradient" : ""}`}
                style={{ animationDelay: `${0.2 + i * 0.12}s` }}
              >
                {line}
              </span>
            </span>
          ))}
        </h1>

        <div className="mt-10 max-w-xl lg:mt-12">
          <p
            className="anim-fade-up text-lg leading-relaxed text-muted md:text-xl"
            style={{ animationDelay: "0.7s" }}
          >
            {hero.statement}
          </p>
          <div
            className="anim-fade-up mt-9 flex flex-wrap gap-3"
            style={{ animationDelay: "0.85s" }}
          >
            <Button href={hero.primaryCta.href}>
              {hero.primaryCta.label}
              <ArrowRight className="transition-transform duration-300 group-hover:translate-x-0.5" />
            </Button>
            <Button href={hero.secondaryCta.href} variant="secondary">
              {hero.secondaryCta.label}
            </Button>
          </div>
        </div>

        {/* Visual: below the copy on small screens, floating beside the headline on large ones */}
        <HeroWorkspace className="mx-auto mb-6 mt-16 max-w-sm sm:max-w-md lg:absolute lg:right-0 lg:top-2 lg:mx-0 lg:mb-0 lg:mt-0 lg:w-[22rem] xl:w-[26rem]" />
      </div>

      <a
        href="#about"
        aria-label="Scroll to About"
        className="anim-fade-up container-x absolute inset-x-0 bottom-8 hidden items-center gap-3 text-muted transition-colors hover:text-ink md:flex"
        style={{ animationDelay: "1.4s" }}
      >
        <ArrowDown width={16} height={16} />
        <span className="eyebrow">Scroll</span>
      </a>
    </section>
  );
}
