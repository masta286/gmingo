import Image from "next/image";
import { SectionHeading } from "@/components/layout/SectionHeading";
import { Reveal } from "@/components/ui/Reveal";
import { about } from "@/data/credentials";
import { site } from "@/data/site";

function ProfileFrame() {
  return (
    <div className="relative mx-auto aspect-[4/5] w-full max-w-sm overflow-hidden rounded-3xl border border-line bg-surface lg:mx-0">
      {about.photo ? (
        <Image
          src={about.photo}
          alt={`Portrait of ${site.name}`}
          fill
          sizes="(min-width: 1024px) 28vw, 90vw"
          className="object-cover"
        />
      ) : (
        <div
          role="img"
          aria-label="Profile photo placeholder"
          className="absolute inset-0 flex items-center justify-center"
        >
          <div aria-hidden className="bg-grid absolute inset-0 opacity-70" />
          <div
            aria-hidden
            className="absolute inset-0"
            style={{
              background:
                "radial-gradient(circle at 50% 35%, rgb(56 189 248 / 0.12), transparent 60%)",
            }}
          />
          <span className="display relative text-[7rem] text-ink/90">
            {site.initials}
          </span>
          <span className="eyebrow absolute inset-x-0 bottom-5 text-center">
            Profile photo
          </span>
        </div>
      )}
      {/* corner brackets */}
      {["left-4 top-4 border-l border-t", "right-4 top-4 border-r border-t", "bottom-4 left-4 border-b border-l", "bottom-4 right-4 border-b border-r"].map(
        (pos) => (
          <span
            key={pos}
            aria-hidden
            className={`absolute size-4 border-accent/50 ${pos}`}
          />
        ),
      )}
    </div>
  );
}

export function About() {
  const [lead, ...rest] = about.paragraphs;

  return (
    <section id="about" aria-labelledby="about-title" className="section-y">
      <div className="container-x">
        <SectionHeading
          id="about-title"
          index="01"
          label="About"
          title={about.title}
          step={0}
        />

        <div className="grid gap-12 lg:grid-cols-12 lg:gap-16">
          <Reveal className="lg:col-span-4">
            <div className="lg:sticky lg:top-28">
              <ProfileFrame />
            </div>
          </Reveal>

          <div className="space-y-6 lg:col-span-7 lg:col-start-6">
            <Reveal>
              <p className="text-2xl leading-snug tracking-tight text-ink md:text-[1.75rem]">
                {lead}
              </p>
            </Reveal>
            {rest.map((p, i) => (
              <Reveal key={p} delay={0.05 * (i + 1)}>
                <p className="text-lg leading-relaxed text-muted">{p}</p>
              </Reveal>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
