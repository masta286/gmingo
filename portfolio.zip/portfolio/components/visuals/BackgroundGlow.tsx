/**
 * Fixed, GPU-friendly ambient light. Pure radial gradients (no blur filters),
 * drifting very slowly. Sits behind everything.
 */
export function BackgroundGlow() {
  return (
    <div
      aria-hidden
      className="pointer-events-none fixed inset-0 -z-10 overflow-hidden"
    >
      <div
        className="animate-drift absolute -left-[20%] -top-[25%] h-[75vmax] w-[75vmax] rounded-full"
        style={{
          background:
            "radial-gradient(circle at center, rgb(34 211 238 / 0.10), transparent 62%)",
        }}
      />
      <div
        className="animate-drift absolute -bottom-[30%] -right-[25%] h-[70vmax] w-[70vmax] rounded-full"
        style={{
          background:
            "radial-gradient(circle at center, rgb(109 94 245 / 0.12), transparent 62%)",
          animationDelay: "-9s",
        }}
      />
    </div>
  );
}
