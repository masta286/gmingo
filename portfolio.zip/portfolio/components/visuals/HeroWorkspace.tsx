"use client";

import {
  motion,
  useMotionValue,
  useReducedMotion,
  useSpring,
  useTransform,
} from "framer-motion";
import { useEffect } from "react";
import { loop } from "@/data/site";
import { cn } from "@/lib/utils";

/**
 * Decorative "product workspace": a wireframe UI, a floating code excerpt and the
 * five-step loop lighting up in sequence. Subtle pointer parallax on desktop.
 * Purely illustrative — hidden from assistive technology.
 */
export function HeroWorkspace({ className }: { className?: string }) {
  const reduce = useReducedMotion();
  const mx = useMotionValue(0);
  const my = useMotionValue(0);
  const sx = useSpring(mx, { stiffness: 70, damping: 18 });
  const sy = useSpring(my, { stiffness: 70, damping: 18 });

  const rotateY = useTransform(sx, [-1, 1], [-5, 5]);
  const rotateX = useTransform(sy, [-1, 1], [4, -4]);
  const layerX = useTransform(sx, [-1, 1], [-8, 8]);
  const layerY = useTransform(sy, [-1, 1], [-6, 6]);

  useEffect(() => {
    if (reduce) return;
    if (!window.matchMedia("(hover: hover) and (pointer: fine)").matches) return;

    const onMove = (e: PointerEvent) => {
      mx.set((e.clientX / window.innerWidth) * 2 - 1);
      my.set((e.clientY / window.innerHeight) * 2 - 1);
    };
    window.addEventListener("pointermove", onMove, { passive: true });
    return () => window.removeEventListener("pointermove", onMove);
  }, [reduce, mx, my]);

  return (
    <div
      aria-hidden
      className={cn("pointer-events-none select-none [perspective:1400px]", className)}
    >
      <div className="anim-fade-up" style={{ animationDelay: "0.9s" }}>
        <motion.div
          style={reduce ? undefined : { rotateX, rotateY, transformStyle: "preserve-3d" }}
          className="relative"
        >
          {/* Main panel */}
          <div className="glass relative overflow-hidden rounded-[1.6rem] p-3.5 shadow-[0_40px_120px_-30px_rgb(34_211_238/0.18)]">
            {/* Top bar */}
            <div className="flex items-center justify-between px-1.5 pb-3">
              <div className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.14em] text-muted">
                <span className="rounded-md bg-white/[0.06] px-2 py-1 text-ink/80">
                  workspace
                </span>
                <span className="hidden xs:inline">product / v0.1</span>
              </div>
              <span className="flex items-center gap-1.5 font-mono text-[10px] uppercase tracking-[0.14em] text-accent">
                <span className="size-1.5 rounded-full bg-accent" />
                building
              </span>
            </div>

            {/* Wireframe product UI */}
            <div className="rounded-xl border border-line bg-bg/70 p-3">
              <div className="flex items-center justify-between">
                <div className="h-2 w-10 rounded-full bg-white/20" />
                <div className="flex gap-1.5">
                  <div className="h-1.5 w-6 rounded-full bg-white/10" />
                  <div className="h-1.5 w-6 rounded-full bg-white/10" />
                  <div className="h-1.5 w-6 rounded-full bg-white/10" />
                </div>
              </div>
              <div className="mt-4 space-y-2">
                <div className="h-3 w-3/4 rounded-full bg-white/[0.16]" />
                <div className="h-3 w-1/2 rounded-full bg-gradient-to-r from-accent/70 to-accent-2/40" />
                <div className="mt-3 h-1.5 w-2/3 rounded-full bg-white/10" />
                <div className="h-1.5 w-1/2 rounded-full bg-white/10" />
              </div>
              <div className="mt-5 grid grid-cols-3 gap-2">
                {[0, 1, 2].map((i) => (
                  <div
                    key={i}
                    className="rounded-lg border border-line bg-white/[0.025] p-2"
                  >
                    <div
                      className={cn(
                        "h-9 rounded-md",
                        i === 1
                          ? "bg-gradient-to-br from-accent/25 to-violet/20"
                          : "bg-white/[0.05]",
                      )}
                    />
                    <div className="mt-2 h-1.5 w-4/5 rounded-full bg-white/15" />
                    <div className="mt-1.5 h-1.5 w-3/5 rounded-full bg-white/[0.08]" />
                  </div>
                ))}
              </div>
            </div>

            {/* The loop */}
            <div className="px-2 pb-1 pt-6">
              <ol className="relative flex justify-between">
                <span className="absolute left-[10%] right-[10%] top-[5px] h-px bg-line-strong" />
                {loop.map((step, i) => (
                  <li key={step.word} className="relative flex-1 text-center">
                    <span
                      className="animate-node-light mx-auto block size-[11px] rounded-full bg-accent"
                      style={{ animationDelay: `${i}s` }}
                    />
                    <span className="mt-2.5 block font-mono text-[9px] uppercase tracking-[0.14em] text-muted">
                      {step.word}
                    </span>
                  </li>
                ))}
              </ol>
            </div>
          </div>

          {/* Floating code excerpt */}
          <motion.div
            style={reduce ? undefined : { x: layerX, y: layerY }}
            className="absolute -bottom-6 -left-4 w-[62%] sm:-left-8 lg:-left-12"
          >
            <div className="glass animate-float rounded-xl bg-surface-2/80 p-3.5 shadow-2xl shadow-black/50">
              <pre className="font-mono text-[10.5px] leading-[1.7] text-muted">
                <code>
                  <span className="text-accent">while</span>
                  {" (growing) {\n"}
                  {"  "}
                  <span className="text-ink/90">learn</span>
                  {"();\n"}
                  {"  "}
                  <span className="text-ink/90">build</span>
                  {"();\n"}
                  {"  "}
                  <span className="text-ink/90">solve</span>
                  {"();"}
                  <span className="animate-caret ml-0.5 inline-block h-3 w-px translate-y-0.5 bg-accent" />
                  {"\n}"}
                </code>
              </pre>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </div>
  );
}
