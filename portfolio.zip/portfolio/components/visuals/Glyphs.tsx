import type { SVGProps } from "react";

const base: SVGProps<SVGSVGElement> = {
  width: 56,
  height: 56,
  viewBox: "0 0 64 64",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 1.5,
  strokeLinecap: "round",
  strokeLinejoin: "round",
  "aria-hidden": true,
  focusable: false,
};

export const WebGlyph = (p: SVGProps<SVGSVGElement>) => (
  <svg {...base} {...p}>
    <rect x="6" y="12" width="52" height="40" rx="6" />
    <path d="M6 22h52" />
    <circle cx="13" cy="17" r="1" fill="currentColor" />
    <circle cx="18" cy="17" r="1" fill="currentColor" />
    <rect x="13" y="29" width="20" height="6" rx="2" />
    <path d="M13 41h30M13 46h18" />
    <rect x="40" y="29" width="11" height="6" rx="2" opacity=".5" />
  </svg>
);

export const SoftwareGlyph = (p: SVGProps<SVGSVGElement>) => (
  <svg {...base} {...p}>
    <path d="M22 20 10 32l12 12M42 20l12 12-12 12" />
    <path d="m37 14-10 36" opacity=".6" />
  </svg>
);

export const ProductGlyph = (p: SVGProps<SVGSVGElement>) => (
  <svg {...base} {...p}>
    <path d="M32 8 54 20v24L32 56 10 44V20L32 8Z" />
    <path d="M10 20l22 12 22-12M32 32v24" opacity=".6" />
  </svg>
);

export const VentureGlyph = (p: SVGProps<SVGSVGElement>) => (
  <svg {...base} {...p}>
    <path d="M8 54h12V42h12V30h12V18h12" />
    <path d="M44 12h12v12" />
    <path d="M8 54h48" opacity=".4" />
  </svg>
);

export const offeringGlyphs = [WebGlyph, SoftwareGlyph, ProductGlyph, VentureGlyph];
