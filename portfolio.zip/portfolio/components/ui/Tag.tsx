import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

export function Tag({
  children,
  className,
}: {
  children: ReactNode;
  className?: string;
}) {
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full border border-line bg-white/[0.03] px-3.5 py-1.5 font-mono text-[0.78rem] tracking-wide text-ink/85 transition-colors duration-300 hover:border-accent/40 hover:text-ink",
        className,
      )}
    >
      {children}
    </span>
  );
}
