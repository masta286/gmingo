import type { AnchorHTMLAttributes, ReactNode } from "react";
import { cn } from "@/lib/utils";

type Variant = "primary" | "secondary" | "ghost";

type ButtonProps = AnchorHTMLAttributes<HTMLAnchorElement> & {
  variant?: Variant;
  children: ReactNode;
};

const variants: Record<Variant, string> = {
  primary:
    "bg-ink text-bg hover:bg-white hover:shadow-[0_0_0_6px_rgb(56_189_248/0.14)]",
  secondary:
    "border border-line-strong text-ink hover:border-accent/60 hover:bg-white/[0.04]",
  ghost: "text-muted hover:text-ink",
};

/** Link styled as a button. Anchor-based so it works for in-page navigation and mailto. */
export function Button({
  variant = "primary",
  className,
  children,
  ...props
}: ButtonProps) {
  return (
    <a
      className={cn(
        "group inline-flex h-12 items-center justify-center gap-2 rounded-full px-6 text-[0.95rem] font-medium transition-all duration-300",
        variants[variant],
        className,
      )}
      {...props}
    >
      {children}
    </a>
  );
}
