import { loop } from "@/data/site";
import { cn } from "@/lib/utils";

/**
 * The LEARN → BUILD → SOLVE → CREATE → GROW motif, reduced to five dots.
 * Used in section headings to quietly mark where each section sits in the story.
 */
export function LoopIndicator({ step }: { step: number }) {
  const active = loop[step];
  if (!active) return null;

  return (
    <div aria-hidden className="flex items-center gap-3">
      <div className="flex items-center gap-1.5">
        {loop.map((s, i) => (
          <span
            key={s.word}
            className={cn(
              "h-1 rounded-full transition-all",
              i === step ? "w-5 bg-accent" : "w-1 bg-white/20",
            )}
          />
        ))}
      </div>
      <span className="eyebrow !text-accent/90">{active.word}</span>
    </div>
  );
}
