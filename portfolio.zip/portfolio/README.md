# Abdallah Nura Kakira — Portfolio

Next.js (App Router) · TypeScript · Tailwind CSS v4 · Framer Motion

## Run it

```bash
npm install
npm run dev        # http://localhost:3000
npm run build      # production build
```

## Updating content (no component changes needed)

Everything editable lives in `data/`:

| File | What it controls |
|---|---|
| `data/site.ts` | Name, hero copy, **email**, **GitHub / LinkedIn / WhatsApp links**, site URL |
| `data/projects.ts` | Selected Work. Empty = "More projects coming soon". Add an object to show a project |
| `data/currently.ts` | The Learning / Building / Exploring block |
| `data/journey.ts` | Timeline years and the "What's next" note |
| `data/skills.ts` | Skill groups and education |
| `data/credentials.ts` | Certifications, activities and the About text + photo path |
| `data/offerings.ts` | The four "What I Build" cards |

### Things to fill in first
1. `data/site.ts` → `contact.email` (the contact form and email links use mailto, so this is required for messages to reach you)
2. `data/site.ts` → `socials[].href` and `display` (empty links show as "Soon")
3. `data/site.ts` → `url` once you have a domain (used for SEO, sitemap, social previews)
4. `data/credentials.ts` → `about.photo` after adding `public/profile.jpg`

### Adding a project
Copy the template in the comment at the top of `data/projects.ts`. Put screenshots in `public/projects/`.
Links and image are optional; buttons only appear when a URL exists.

## Deploy
Push to GitHub and import the repo on Vercel. No environment variables needed for v1.
