import { ImageResponse } from "next/og";

export const alt = "Abdallah Nura Kakira — I build digital products.";
export const size = { width: 1200, height: 630 };
export const contentType = "image/png";

export default function OpengraphImage() {
  return new ImageResponse(
    (
      <div
        style={{
          width: "100%",
          height: "100%",
          display: "flex",
          flexDirection: "column",
          justifyContent: "space-between",
          padding: 72,
          background:
            "radial-gradient(circle at 15% 10%, rgba(34,211,238,0.18), transparent 50%), radial-gradient(circle at 90% 95%, rgba(109,94,245,0.22), transparent 50%), #07080a",
          color: "#ededea",
        }}
      >
        <div style={{ fontSize: 26, letterSpacing: 6, color: "#8a8f98" }}>
          ABDALLAH NURA KAKIRA
        </div>
        <div
          style={{
            display: "flex",
            flexDirection: "column",
            fontSize: 132,
            fontWeight: 700,
            lineHeight: 0.95,
            letterSpacing: -4,
          }}
        >
          <span>I BUILD</span>
          <span>DIGITAL</span>
          <span style={{ color: "#38bdf8" }}>PRODUCTS.</span>
        </div>
        <div style={{ fontSize: 26, color: "#8a8f98" }}>
          Software Developer · Computer Science Student · Product Builder
        </div>
      </div>
    ),
    size,
  );
}
