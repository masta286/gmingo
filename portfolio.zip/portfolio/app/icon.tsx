import { ImageResponse } from "next/og";

export const size = { width: 64, height: 64 };
export const contentType = "image/png";

export default function Icon() {
  return new ImageResponse(
    (
      <div
        style={{
          width: "100%",
          height: "100%",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          background: "#07080a",
          color: "#38bdf8",
          fontSize: 30,
          fontWeight: 700,
          borderRadius: 14,
          border: "2px solid rgba(255,255,255,0.12)",
        }}
      >
        AK
      </div>
    ),
    size,
  );
}
