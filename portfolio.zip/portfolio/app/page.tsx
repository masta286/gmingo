import { About } from "@/components/sections/About";
import { Contact } from "@/components/sections/Contact";
import { Credentials } from "@/components/sections/Credentials";
import { CurrentlyBuilding } from "@/components/sections/CurrentlyBuilding";
import { Education } from "@/components/sections/Education";
import { Hero } from "@/components/sections/Hero";
import { Journey } from "@/components/sections/Journey";
import { Projects } from "@/components/sections/Projects";
import { Skills } from "@/components/sections/Skills";
import { WhatIBuild } from "@/components/sections/WhatIBuild";

export default function Home() {
  return (
    <>
      <Hero />
      <About />
      <WhatIBuild />
      <Projects />
      <CurrentlyBuilding />
      <Journey />
      <Skills />
      <Education />
      <Credentials />
      <Contact />
    </>
  );
}
